DEBUG = False  # Change this to True to see logs
